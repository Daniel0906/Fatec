import React, { Component } from 'react';
import { View, StyleSheet, ScrollView, Image, Text } from 'react-native';
 


class App extends Component{
  render(){      
    return(
      <View style={styles.container}>
        <View style={styles.title}>
            <Image
                  style={styles.img}
                  source = {require('./img/title.png')}
              />
        </View>
        <ScrollView horizontal={true} showsHorizontalScrollIndicator={true}>
          <View style={styles.box}>
              <Image
                  style={styles.img}
                  source = {require('./img/img1.png')}
              />
              <Text> Iphone 14 Pro Max {"\n"}</Text>
              
              <Text>R$ 8.000,00 </Text>
          </View>
          <View style={styles.box}>
              <Image
                  style={styles.img}
                  source = {require('./img/img2.png')}
              />
              <Text> Iphone 8 Plus {"\n"}</Text>
              
              <Text>R$ 1280,00 </Text>
          </View>
          <View style={styles.box}>
              <Image
                  style={styles.img}
                  source = {require('./img/img3.png')}
              />
              <Text> Iphone XS {"\n"}</Text>
              
              <Text>R$ 2.300,00 </Text>
          </View>
          <View style={styles.box}>
              <Image
                  style={styles.img}
                  source = {require('./img/img4.png')}
              />
              <Text> Iphone 12 Pro Max {"\n"}</Text>
              
              <Text>R$ 3.500,00 </Text>
          </View>
        </ScrollView>
      </View>
    )
  }
}


const styles = StyleSheet.create({ 
  container:{
    flex: 1,
    alignItems: 'center',
    backgroundColor: 'gray',
  },
  box:{
    height: 300,
    width: 200,
    padding: 40,
    borderRadius: 20,
    marginRight: 10,
    backgroundColor: '#D3D3D3',
  },
  img:{
    height: 150,
    width: 120,
  },
  title:{
    padding: 50,
  }
})


export default App;