//Obtedo os elementos vindos do HTML
const casas = document.getElementsByTagName('input');
const b_reiniciar = document.getElementById('reiniciar');
const label_jogador = document.getElementById('jogador');

//Definindo o estado do jogador 
//( _ = jogador indefinido; X = jogador X; O = jogador O)
var jogador = '_';
var vencedor = '_';

//Função p escolher aleatoriamente um jogador inicial
//sortearJogador();

//Define a resposta ao evento de clique nas casas do "tabuleiro"
for(var i = 0; i < 9; i++){
    casas[i].addEventListener('click', (event) => {
        //se a casa estiver vazia e ninguém tiver vencido a partida
        if((event.target.value == '_') && (vencedor == '_')){

            //preenche a casa com X ou O
            event.target.value = jogador;

            //torna o valor da casa visível
            event.target.style.color = 'black';

            //função que troca a vez do jogador
            trocarJogador();

            //Executa a função vitoria()
            vencedor = vitoria();
        }
    });
}

//Define a resposta ao evento de clique no botão Reiniciar
b_reiniciar.addEventListener('click', (event) =>{
    for(var i = 0; i < 9; i++){
        casas[i].value = '_';
        casas[i].style.color = 'white';
        casas[i].style.backgroundColor = 'white'; 
    }

    //Reseta o vencedor
    vencedor = '_';
    sortearJogador();
});

//Usa uma função que decide aleatoriamente o jogador a fazer a primeira jogada
var sortearJogador = function(){
    if(Math.floor(Math.random()*2) == 0){
        jogador = 'O'
        label_jogador.innerText = 'O';
        label_jogador.style.color = 'red';
    }else{
        jogador = 'X'
        label_jogador.innerText = 'X';
        label_jogador.style.color = 'blue';
    }
}
sortearJogador();
//Alterna a vez entre os jogadores X e O
var trocarJogador = function(){
    if(jogador == 'X'){
        jogador = 'O';
        label_jogador.innerText = 'O';
        label_jogador.style.color = 'red';
    }else{
        jogador = 'X';
        label_jogador.innerText = 'X';
        label_jogador.style.color = 'blue';
    }
}

//Verifica se uma condição de vitória foi atingida
var vitoria = function(){
    if((casas[0].value == casas[1].value) && (casas[1].value == casas[2].value) && casas[0].value != '_'){
        casas[0].style.backgroundColor = '#0F0';
        casas[1].style.backgroundColor = '#0F0';
        casas[2].style.backgroundColor = '#0F0';

        return casas[0].value;
    }else if((casas[3].value == casas[4].value) && (casas[4].value == casas[5].value) && casas[3].value != '_'){
        casas[3].style.backgroundColor='#0F0';
        casas[4].style.backgroundColor='#0F0';
        casas[5].style.backgroundColor='#0F0';

        return casas[3].value;

    }else if((casas[6].value==casas[7].value) && (casas[7].value==casas[8].value) && casas[6].value!='_' ) {
        casas[6].style.backgroundColor='#0F0';
        casas[7].style.backgroundColor='#0F0';
        casas[8].style.backgroundColor='#0F0';

        return casas[6].value;

    }else if((casas[0].value==casas[3].value) && (casas[3].value==casas[6].value) && casas[0].value!='_' ) {
        casas[0].style.backgroundColor='#0F0';
        casas[3].style.backgroundColor='#0F0';
        casas[6].style.backgroundColor='#0F0';

        return casas[0].value;

    }else if((casas[1].value==casas[4].value) && (casas[4].value==casas[7].value) && casas[1].value!='_' ) {
        casas[1].style.backgroundColor='#0F0';
        casas[4].style.backgroundColor='#0F0';
        casas[7].style.backgroundColor='#0F0';

        return casas[1].value;

    }else if((casas[2].value==casas[5].value) && (casas[5].value==casas[8].value) && casas[2].value!='_' ) {
        casas[2].style.backgroundColor='#0F0';
        casas[5].style.backgroundColor='#0F0';
        casas[8].style.backgroundColor='#0F0';

        return casas[2].value;
    }else if((casas[0].value==casas[4].value) && (casas[4].value==casas[8].value) && casas[0].value!='_' ) {
        casas[0].style.backgroundColor='#0F0';
        casas[4].style.backgroundColor='#0F0';
        casas[8].style.backgroundColor='#0F0';

        return casas[0].value;

    }else if((casas[2].value==casas[4].value) && (casas[4].value==casas[6].value) && casas[2].value!='_' ) {
        casas[2].style.backgroundColor='#0F0';
        casas[4].style.backgroundColor='#0F0';
        casas[6].style.backgroundColor='#0F0';

        return casas[2].value;
    }

    return'_';
}































